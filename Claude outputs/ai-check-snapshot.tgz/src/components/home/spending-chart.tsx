import { useState } from 'react';
import { LayoutChangeEvent, Pressable, StyleSheet, View, useColorScheme } from 'react-native';
import Svg, { Circle, Defs, G, Line, LinearGradient, Path, Stop } from 'react-native-svg';

import { ThemedText } from '@/components/ui/themed-text';
import { Colors, FontSize, Radius } from '@/constants/theme';
import { useT } from '@/i18n';
import { mondayIndex, monthShort, weekdayShort } from '@/i18n/format';
import type { ChartPeriod, ChartPoint } from '@/context/TransactionsContext';
import { formatMoney } from '@/utils/currency';

const PADDING_TOP = 46; // room above the plot so the tooltip never gets clipped
const PLOT_HEIGHT = 128; // from the top padding down to the x-axis line
const BASE_GAP = 16; // empty space between the x-axis line and the lowest dot (raise/lower to taste)
const PADDING_BOTTOM = 8;
const CHART_HEIGHT = PADDING_TOP + PLOT_HEIGHT + PADDING_BOTTOM;
const TOOLTIP_WIDTH = 104;

export const PERIOD_COLOR: Record<ChartPeriod, { light: string; dark: string }> = {
  week: { light: '#3654A6', dark: '#7C93D8' }, // blue
  month: { light: '#8A4FBF', dark: '#B98CE0' }, // purple
  year: { light: '#1F8A70', dark: '#57C9A6' }, // green
};

const LIMIT_COLOR = '#D97706';

type Coord = { x: number; y: number };

// Catmull-Rom -> cubic Bezier conversion, so the line curves smoothly through
// every point instead of joining them with straight segments.
function smoothLinePath(coords: Coord[]): string {
  if (coords.length === 0) return '';
  if (coords.length === 1) return `M ${coords[0].x} ${coords[0].y}`;
  if (coords.length === 2) {
    return `M ${coords[0].x} ${coords[0].y} L ${coords[1].x} ${coords[1].y}`;
  }

  let d = `M ${coords[0].x} ${coords[0].y}`;
  for (let i = 0; i < coords.length - 1; i++) {
    const p0 = coords[i - 1] ?? coords[i];
    const p1 = coords[i];
    const p2 = coords[i + 1];
    const p3 = coords[i + 2] ?? p2;

    const cp1x = p1.x + (p2.x - p0.x) / 6;
    const cp1y = p1.y + (p2.y - p0.y) / 6;
    const cp2x = p2.x - (p3.x - p1.x) / 6;
    const cp2y = p2.y - (p3.y - p1.y) / 6;

    d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
  }
  return d;
}

/** Axis label in the current language: "Mon" / "Isn" for week points, "Sep" for month points, "2026" for years. */
export function pointLabel(point: ChartPoint, period: ChartPeriod) {
  if (period === 'week') {
    const [y, m, d] = point.key.split('-').map(Number);
    return weekdayShort(mondayIndex(new Date(y, m - 1, d)));
  }
  if (period === 'month') return monthShort(Number(point.key.split('-')[1]));
  return point.label;
}

// "Mon, 21 Sep" for week points, "Sep 2026" for month points, "2026" for year points.
function tooltipTitle(point: ChartPoint, period: ChartPeriod) {
  if (period === 'week') {
    const [y, m, d] = point.key.split('-').map(Number);
    return `${weekdayShort(mondayIndex(new Date(y, m - 1, d)))}, ${d} ${monthShort(m - 1)}`;
  }
  if (period === 'month') return `${pointLabel(point, period)} ${point.key.split('-')[0]}`;
  return point.label;
}

export function SpendingChart({
  data,
  period,
  dailyLimit,
}: { 
  data: ChartPoint[];
  period: ChartPeriod;
  dailyLimit?: number;
}) {
  const { t } = useT();
  const scheme = useColorScheme();
  const isDark = scheme === 'dark';
  const colors = Colors[isDark ? 'dark' : 'light'];
  const accent = PERIOD_COLOR[period][isDark ? 'dark' : 'light'];
  const gradientId = `spendingArea-${period}`;

  const [width, setWidth] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);

  function onLayout(e: LayoutChangeEvent) {
    setWidth(e.nativeEvent.layout.width);
  }

  const n = data.length;
  const showLimit = period === 'week' && !!dailyLimit && dailyLimit > 0;
  const max = Math.max(...data.map((d) => d.value), showLimit ? dailyLimit! : 0, 1);
  const hasData = data.some((d) => d.value > 0);

  const colWidth = n > 0 ? width / n : 0;
  const baselineY = PADDING_TOP + PLOT_HEIGHT; // the x-axis line
  const dataBottom = baselineY - BASE_GAP; // where a value of 0 is drawn
  const dataHeight = PLOT_HEIGHT - BASE_GAP;
  const limitY = showLimit ? PADDING_TOP + dataHeight * (1 - Math.min(dailyLimit! / max, 1)) : null;

  // Points sit in the middle of their column, so they line up with the labels underneath.
  const coords = data.map((point, i) => ({
    x: colWidth * (i + 0.5),
    y: PADDING_TOP + dataHeight * (1 - point.value / max),
    point,
    i,
  }));
  const drawn = coords.filter((c) => !c.point.isFuture);

  const linePath = smoothLinePath(drawn);
  // The fill stops at `dataBottom`, so it never touches the x-axis line.
  const areaPath =
    drawn.length > 1
      ? `${linePath} L ${drawn[drawn.length - 1].x} ${dataBottom} L ${drawn[0].x} ${dataBottom} Z`
      : '';

  const active = selected !== null ? coords[selected] : undefined;
  const tooltipLeft = active ? Math.min(Math.max(active.x - TOOLTIP_WIDTH / 2, 0), width - TOOLTIP_WIDTH) : 0;
  const tooltipTop = active ? Math.max(active.y - 52, 0) : 0;

  return (
    <View>
      <View style={styles.chartArea} onLayout={onLayout}>
        {width > 0 && (
          <>
            <Svg width={width} height={CHART_HEIGHT}>
              <Defs>
                <LinearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                  <Stop offset="0" stopColor={accent} stopOpacity={0.3} />
                  <Stop offset="1" stopColor={accent} stopOpacity={0} />
                </LinearGradient>
              </Defs>

              {/* x-axis line */}
              <Line x1={0} x2={width} y1={baselineY} y2={baselineY} stroke={colors.divider} strokeWidth={1} />
              
              {limitY !== null && (
                <Line
                  x1={0}
                  x2={width}
                  y1={limitY}
                  y2={limitY}
                  stroke={LIMIT_COLOR}
                  strokeOpacity={0.6}
                  strokeWidth={1}
                  strokeDasharray="4 4"
                />
              )}

              {active && !active.point.isFuture && (
                <Line
                  x1={active.x}
                  x2={active.x}
                  y1={active.y}
                  y2={baselineY}
                  stroke={accent}
                  strokeOpacity={0.35}
                  strokeWidth={1.5}
                  strokeDasharray="3 4"
                />
              )}

              {hasData && areaPath ? <Path d={areaPath} fill={`url(#${gradientId})`} stroke="none" /> : null}
              {hasData && drawn.length > 1 ? (
                <Path
                  d={linePath}
                  fill="none"
                  stroke={accent}
                  strokeWidth={2.5}
                  strokeLinejoin="round"
                  strokeLinecap="round"
                />
              ) : null}

              {hasData &&
                drawn.map((c) => {
                  const isSelected = c.i === selected;
                  const isToday = !!c.point.isToday;
                  return (
                    <G key={c.point.key}>
                      {isSelected && <Circle cx={c.x} cy={c.y} r={10} fill={accent} fillOpacity={0.18} />}
                      <Circle
                        cx={c.x}
                        cy={c.y}
                        r={isSelected ? 5.5 : isToday ? 5 : 3}
                        fill={isSelected || isToday ? accent : colors.background}
                        stroke={accent}
                        strokeWidth={isSelected || isToday ? 0 : 2}
                      />
                    </G>
                  );
                })}
            </Svg>

            {!hasData && (
              <View style={styles.emptyOverlay} pointerEvents="none">
                <ThemedText type="small" style={{ color: colors.textSecondary }}>
                  {t('home.chart.noSpending')}
                </ThemedText>
              </View>
            )}

            {/* Tap targets: one full-height column per point. */}
            <View style={styles.tapRow}>
              {data.map((point, i) => (
                <Pressable
                  key={point.key}
                  style={styles.tapColumn}
                  disabled={point.isFuture}
                  onPress={() => setSelected((prev) => (prev === i ? null : i))}
                  accessibilityRole="button"
                  accessibilityLabel={`${tooltipTitle(point, period)}, ${formatMoney(point.value)}`}
                />
              ))}
            </View>

            {active && !active.point.isFuture && (
              <View
                pointerEvents="none"
                style={[styles.tooltip, { left: tooltipLeft, top: tooltipTop, backgroundColor: colors.text }]}
              >
                <ThemedText type="small" style={[styles.tooltipTitle, { color: colors.background }]} numberOfLines={1}>
                  {tooltipTitle(active.point, period)}
                </ThemedText>
                <ThemedText style={[styles.tooltipValue, { color: colors.background }]} numberOfLines={1}>
                  {formatMoney(active.point.value)}
                </ThemedText>
              </View>
            )}
            {limitY !== null && (
              <View
                pointerEvents="none"
                style={[styles.limitLabel, { top: Math.max(limitY - 13, 0) }]}
              >
                <ThemedText type="small" style={styles.limitText}>
                  {t('home.chart.limit', { amount: formatMoney(dailyLimit!) })}
                </ThemedText>
              </View>
            )}
          </>
        )}
      </View>

      <View style={styles.labelRow}>
        {data.map((point, i) => {
          const highlighted = i === selected || (selected === null && point.isToday);
          return (
            <View key={point.key} style={styles.labelColumn}>
              <ThemedText
                type="small"
                style={[
                  styles.label,
                  { color: highlighted ? accent : colors.textSecondary },
                  highlighted && styles.labelActive,
                  point.isFuture && styles.labelFuture,
                  n > 7 && styles.labelDense,
                ]}
                numberOfLines={1}
              >
                {pointLabel(point, period)}
              </ThemedText>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  chartArea: { width: '100%', height: CHART_HEIGHT },
  emptyOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: PADDING_TOP,
    height: PLOT_HEIGHT - BASE_GAP,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tapRow: { position: 'absolute', top: 0, left: 0, right: 0, height: CHART_HEIGHT, flexDirection: 'row' },
  tapColumn: { flex: 1 },
  tooltip: {
    position: 'absolute',
    width: TOOLTIP_WIDTH,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: Radius.sm,
    alignItems: 'center',
  },
  tooltipTitle: { fontSize: FontSize.micro, lineHeight: 14, opacity: 0.7 },
  tooltipValue: { fontSize: FontSize.label, lineHeight: 18, fontWeight: '700' },
  labelRow: { flexDirection: 'row', marginTop: 4 },
  labelColumn: { flex: 1, alignItems: 'center' },
  label: {},
  labelActive: { fontWeight: '700' },
  labelFuture: { opacity: 0.4 },
  labelDense: { fontSize: FontSize.micro },
  // A small caption sitting just above the dashed line, so the line itself stays quiet.
  limitLabel: { position: 'absolute', right: 2 },
  limitText: { color: LIMIT_COLOR, fontSize: 10, lineHeight: 12, fontWeight: '600', opacity: 0.85 },
});