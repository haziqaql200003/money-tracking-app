import { Ionicons } from '@expo/vector-icons';
import { useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { LineChart, type Readout } from '@/components/analyse/line-chart';
import { BarChart } from '@/components/analyse/ui/bar-chart';
import { ThemedText } from '@/components/ui/themed-text';
import { Chip } from '@/components/ui/chip';
import { FontSize, Radius, Spacing } from '@/constants/theme';
import { usePlan } from '@/context/PlanContext';
import { usePrivacy } from '@/context/PrivacyContext';
import { useSettings } from '@/context/SettingsContext';
import { useTransactions } from '@/context/TransactionsContext';
import { useLedger } from '@/hooks/use-ledger';
import { useTheme } from '@/hooks/use-theme';
import { useT } from '@/i18n';
import { formatCompact, formatMoney } from '@/utils/currency';
import { monthLabel } from '@/utils/dates';
import { buildOutlook, forecastSeries, monthlySums, savingFlows, savingsRate, runwayMonths, type Band } from '@/utils/forecast';
import { goalMonthSaved, goalProjection, goalSaved, activeGoals } from '@/utils/goals';
import { monthKeysEnding } from '@/utils/insights';
import { isEnded, isTransfer, monthlyEquivalent } from '@/utils/recurring';
import { looksLikeSavings } from '@/utils/saved';
import { cycleOf, shiftCycle } from '@/utils/cycle';
import { p1 } from '@/utils/percent';

const MASK = 'RM ••••';
const HORIZON = 3;

function shiftMonth(key: string, by: number) {
  const [y, m] = key.slice(0, 7).split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1 + by, 1));
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}`;
}
/** The financial months after the one holding today (payday cycles, so a 25th payday does not repeat a month). */
function nextKeys(todayKey: string, n: number) {
  return Array.from({ length: n }, (_, i) => shiftCycle(cycleOf(todayKey), i + 1));
}
const HIST = 6;

/**
 * forecast = the next months (spending, income, saving, left over) and the savings projection: all ESTIMATES.
 * savings  = savings balance, rate, runway, money saved month by month and goals: real records, plus goal pace.
 */
type Props = { months: number; todayKey: string; part: 'forecast' | 'savings' };

/** The "Forecast" tab of Faham: this month so far, the next months for spending, income and saving, and goals. */
export function AnalyseForecast({ months, todayKey, part }: Props) {
  const colors = useTheme();
  const { t } = useT();
  const { transfers, accounts, recurringRules, accountBalance } = useTransactions();
  // Ledger entries: corrections and moved money are not income or spending, refunds lower spending.
  const { entries: transactions } = useLedger();
  const { goals, goalEntries } = usePlan();
  const { hideAmounts } = usePrivacy();
  const { savingsTarget } = useSettings();

  const money = (n: number) => (hideAmounts ? MASK : formatMoney(n));
  const compact = (n: number) => (hideAmounts ? '••' : formatCompact(n));
  const monthKey = cycleOf(todayKey);

  const d = useMemo(() => {
    const span = Math.max(months, 6);
    const past = monthKeysEnding(todayKey, span + 1).slice(0, -1); // complete months only
    const everyday = monthlySums(
      transactions.filter((x) => x.type === 'debit' && !x.recurringId).map((x) => ({ date: x.date, amount: x.amount })),
      past,
    );
    const income = monthlySums(transactions.filter((x) => x.type === 'credit').map((x) => ({ date: x.date, amount: x.amount })), past);
    const savingIds = new Set(accounts.filter((a) => looksLikeSavings(a)).map((a) => a.id));
    const flows = savingFlows(transfers, (id) => savingIds.has(id));
    const saving = monthlySums(flows, past);
    const fixedMonthly = recurringRules
      .filter((r) => r.active && !isEnded(r) && !isTransfer(r) && r.type === 'debit')
      .reduce((s, r) => s + monthlyEquivalent(r), 0);
    const outlook = buildOutlook({ everydayHistory: everyday, incomeHistory: income, savingHistory: saving, fixedMonthly, horizon: HORIZON + 1 });

    let spent = 0;
    let earned = 0;
    for (const x of transactions) {
      if (cycleOf(x.date) !== monthKey || x.date > todayKey) continue;
      if (x.type === 'debit') spent += x.amount;
      else earned += x.amount;
    }
    const savedNow = monthlySums(flows, [monthKey])[0] ?? 0;
    const planned = goals.filter((g) => !g.paused).reduce((s, g) => s + (g.monthly ?? 0), 0);

    const balance = accounts.filter((a) => !a.hidden && savingIds.has(a.id)).reduce((s, a) => s + accountBalance(a.id), 0);
    const spendAll = monthlySums(transactions.filter((x) => x.type === 'debit').map((x) => ({ date: x.date, amount: x.amount })), past);
    const flowsAll = flows;
    const totalSaved = saving.reduce((s, v) => s + v, 0);
    const totalIncome = income.reduce((s, v) => s + v, 0);
    const avgSpend = outlook.expense.average;
    return {
      past,
      spendAll,
      flowsAll,
      outlook,
      saving,
      income,
      spent,
      earned,
      savedNow,
      planned,
      balance,
      rate: savingsRate(totalSaved, totalIncome),
      runway: runwayMonths(balance, avgSpend),
      fixedMonthly,
      monthsUsed: outlook.expense.monthsUsed,
    };
  }, [transactions, transfers, accounts, recurringRules, goals, months, todayKey, monthKey, accountBalance]);

  const goalRows = useMemo(
    () =>
      activeGoals(goals, goalEntries).map((g) => {
        const p = goalProjection(g, goalEntries, todayKey);
        const remaining = Math.max(0, g.target - goalSaved(goalEntries, g.id));
        let need: number | null = null;
        if (g.deadline && remaining > 0) {
          const left = (new Date(g.deadline).getTime() - new Date(todayKey).getTime()) / (30.4375 * 86400000);
          need = Math.round((remaining / Math.max(1, left)) * 100) / 100;
        }
        return { g, p, need, saved: goalSaved(goalEntries, g.id), thisMonth: goalMonthSaved(goalEntries, g.id, monthKey) };
      }),
    [goals, goalEntries, todayKey, monthKey],
  );

  const [pick, setPick] = useState<string | null>(null);
  const picked = goalRows.find((r) => r.g.id === pick) ?? goalRows[0] ?? null;

  const goalChart = useMemo(() => {
    if (!picked) return null;
    const { g, p, need } = picked;
    const saved = goalSaved(goalEntries, g.id);
    const remaining = Math.max(0, g.target - saved);
    const rate = p.perMonth > 0 ? p.perMonth : (g.monthly ?? 0);
    const monthsPace = remaining > 0 && rate > 0 ? Math.ceil(remaining / rate) : 0;
    const monthsDeadline = g.deadline ? Math.max(1, Math.round((new Date(g.deadline).getTime() - new Date(todayKey).getTime()) / (30.4375 * 86400000))) : 0;
    const horizon = Math.min(60, Math.max(3, monthsPace, monthsDeadline, 6));
    const histKeys = Array.from({ length: HIST }, (_, i) => shiftMonth(todayKey, i - (HIST - 1)));
    const hist = histKeys.map((k, i) => {
      if (i === HIST - 1) return saved;
      const end = `${k}-31`;
      return Math.round(goalEntries.filter((e) => e.goalId === g.id && e.date <= end).reduce((a, e) => a + e.amount, 0) * 100) / 100;
    });
    const fut = Array.from({ length: horizon }, (_, i) => shiftMonth(todayKey, i + 1));
    const nulls = <T,>(n: number) => Array.from({ length: n }, () => null as T | null);
    const cap = (v: number) => Math.min(g.target, v);
    const actual = [...hist, ...nulls<number>(horizon)];
    const pace = rate > 0 ? [...nulls<number>(HIST - 1), saved, ...fut.map((_, i) => cap(saved + rate * (i + 1)))] : null;
    const suggest = need !== null && remaining > 0 ? [...nulls<number>(HIST - 1), saved, ...fut.map((_, i) => (i + 1 <= monthsDeadline ? cap(saved + need * (i + 1)) : null))] : null;
    return {
      labels: [...histKeys, ...fut].map((k) => monthLabel(k, 'short')),
      actual,
      pace,
      suggest,
      target: g.target,
      monthsPace,
      rate,
      need,
      remaining,
      done: remaining <= 0,
    };
  }, [picked, goalEntries, todayKey]);

  const totalChart = useMemo(() => {
    const H = 6;
    const sv = forecastSeries(d.saving, H + 1);
    const hk = d.past.slice(-HIST);
    // Savings level at the end of each past month, ending at today's real balance.
    const fut = d.flowsAll.filter((f) => cycleOf(f.date) > hk[hk.length - 1]).reduce((a, f) => a + f.amount, 0);
    let level = d.balance - fut;
    const hist: number[] = new Array(hk.length);
    for (let i = hk.length - 1; i >= 0; i--) {
      hist[i] = Math.round(level * 100) / 100;
      level -= d.saving[d.saving.length - hk.length + i] ?? 0;
    }
    const nowVal = hist[hist.length - 1] ?? d.balance;
    const nulls = (n: number) => Array.from({ length: n }, () => null as number | null);
    let acc = nowVal;
    const mid: number[] = [];
    const lo: number[] = [];
    const hi: number[] = [];
    let accLo = nowVal;
    let accHi = nowVal;
    sv.points.forEach((p) => {
      acc += p.value;
      accLo += p.low;
      accHi += p.high;
      mid.push(Math.round(acc));
      lo.push(Math.round(accLo));
      hi.push(Math.round(accHi));
    });
    const keys2 = [...hk, cycleOf(todayKey), ...nextKeys(todayKey, H)];
    return {
      labels: keys2.map((k) => monthLabel(k, 'short')),
      hist: [...hist, ...nulls(H + 1)],
      mid: [...nulls(hk.length - 1), hist[hist.length - 1] ?? nowVal, ...mid],
      lo: [...nulls(hk.length - 1), hist[hist.length - 1] ?? nowVal, ...lo],
      hi: [...nulls(hk.length - 1), hist[hist.length - 1] ?? nowVal, ...hi],
      split: hk.length,
    };
  }, [d, todayKey]);

  const spendChart = useMemo(() => {
    const hk = d.past.slice(-HIST);
    const hist = d.spendAll.slice(-HIST);
    const ex = d.outlook.expense.points;
    const nulls = (n: number) => Array.from({ length: n }, () => null as number | null);
    const last = hist[hist.length - 1] ?? 0;
    return {
      labels: [...hk, cycleOf(todayKey), ...nextKeys(todayKey, HORIZON)].map((k) => monthLabel(k, 'short')),
      hist: [...hist, ...nulls(HORIZON + 1)],
      mid: [...nulls(hk.length - 1), last, ...ex.map((p) => p.value)],
      lo: [...nulls(hk.length - 1), last, ...ex.map((p) => p.low)],
      hi: [...nulls(hk.length - 1), last, ...ex.map((p) => p.high)],
      split: hk.length,
    };
  }, [d, todayKey]);


  /** Readout for a past-plus-forecast line chart: the real value for past months, the guess and its range for coming ones. */
  const bandReadout = (c: { labels: string[]; hist: (number | null)[]; mid: (number | null)[]; lo: (number | null)[]; hi: (number | null)[]; split: number }, forecastColor: string) =>
    (i: number): Readout => {
      if (i < c.split) {
        const real = c.hist[i];
        return { title: c.labels[i], rows: real === null || real === undefined ? [] : [{ label: t('fc.goalChart.actual'), value: money(real), color: colors.accent }] };
      }
      return {
        title: `${c.labels[i]} · ${t('plan.deep.guess')}`,
        rows: [
          { label: t('fc.totalChart.forecast'), value: money(c.mid[i] ?? 0), color: forecastColor },
          { label: t('fc.totalChart.range'), value: `${compact(c.lo[i] ?? 0)} – ${compact(c.hi[i] ?? 0)}`, color: colors.textSecondary },
        ],
      };
    };

  const legend = (items: { c: string; k: string; dashed?: boolean }[]) => (
    <View style={styles.legend}>
      {items.map((i) => (
        <View key={i.k} style={styles.legendItem}>
          <View style={{ width: 14, height: 0, borderTopWidth: 3, borderTopColor: i.c, borderStyle: i.dashed ? 'dashed' : 'solid' }} />
          <ThemedText type="small" style={{ color: colors.textSecondary }}>{i.k}</ThemedText>
        </View>
      ))}
    </View>
  );

  const muted = { color: colors.textSecondary };
  const card = [styles.card, { backgroundColor: colors.backgroundElement }];
  const section = (title: string) => (
    <ThemedText type="smallBold" style={styles.sectionTitle}>
      {title}
    </ThemedText>
  );
  const keys = nextKeys(todayKey, HORIZON);
  const rough = d.monthsUsed < 3;
  const hasHistory = d.monthsUsed > 0 || d.saving.some((v) => v !== 0);
  // Savings target line: the pengguna's target share (Profile) of their usual income over the same months.
  const shownSaving = d.saving.slice(-6);
  const shownIncome = d.income.slice(-6).filter((v) => v > 0);
  const avgIncome = shownIncome.length ? shownIncome.reduce((a, v) => a + v, 0) / shownIncome.length : 0;
  const targetAmount = savingsTarget > 0 ? Math.round(((avgIncome * savingsTarget) / 100) * 100) / 100 : 0;
  const metTarget = targetAmount > 0 ? shownSaving.filter((v) => v >= targetAmount).length : 0;

  const bandRow = (label: string, bands: Band[], tone?: string) => (
    <View style={styles.block}>
      <ThemedText type="smallBold">{label}</ThemedText>
      {bands.map((b, i) => (
        <View key={keys[i]} style={styles.bandRow}>
          <ThemedText type="small" style={[muted, styles.monthCol]}>{monthLabel(keys[i], 'short')}</ThemedText>
          <View style={styles.flex}>
            <ThemedText type="smallBold" style={tone ? { color: tone } : undefined}>{money(b.value)}</ThemedText>
            <ThemedText type="small" style={muted}>{t('fc.next.range', { low: compact(b.low), high: compact(b.high) })}</ThemedText>
          </View>
        </View>
      ))}
    </View>
  );

  return (
    <View>
      {part === 'forecast' ? (
      <>
      {section(t('fc.next.title', { n: HORIZON }))}
      <View style={card}>
        {!hasHistory ? (
          <ThemedText type="small" style={muted}>{t('fc.next.empty')}</ThemedText>
        ) : (
          <>
            {bandRow(t('fc.next.expense'), d.outlook.expense.points.slice(1), colors.negative)}
            {bandRow(t('fc.next.income'), d.outlook.income.points.slice(1), colors.positive)}
            {bandRow(t('fc.next.saving'), d.outlook.saving.points.slice(1), colors.accent)}
            {bandRow(t('fc.next.left'), d.outlook.left.slice(1))}
            <ThemedText type="small" style={muted}>{t('fc.next.how', { fixed: money(d.fixedMonthly) })}</ThemedText>
            {rough ? <ThemedText type="small" style={muted}>{t('fc.next.rough')}</ThemedText> : null}
          </>
        )}
      </View>
      </>
      ) : null}

      {part === 'savings' ? (
      <>
      {section(t('fc.sav.title'))}
      <View style={card}>
        <View style={styles.trio}>
          <View style={styles.flex}>
            <ThemedText type="small" style={muted}>{t('fc.sav.balance')}</ThemedText>
            <ThemedText type="smallBold">{money(d.balance)}</ThemedText>
          </View>
          <View style={styles.flex}>
            <ThemedText type="small" style={muted}>{t('fc.sav.rate')}</ThemedText>
            <ThemedText type="smallBold">{d.rate === null ? '—' : `${p1(d.rate)}%`}</ThemedText>
          </View>
          <View style={styles.flex}>
            <ThemedText type="small" style={muted}>{t('fc.sav.runway')}</ThemedText>
            <ThemedText type="smallBold">{d.runway === null ? '—' : t('fc.sav.runwayValue', { n: d.runway })}</ThemedText>
          </View>
        </View>
        <ThemedText type="small" style={muted}>
          {t('fc.now.saved')}: <ThemedText type="smallBold" style={{ color: colors.accent }}>{money(d.savedNow)}</ThemedText>
          {d.planned > 0 ? ` ${t('fc.now.planned', { amount: money(d.planned) })}` : ''}
        </ThemedText>
        <ThemedText type="smallBold" style={styles.gap}>{t('fc.sav.monthly')}</ThemedText>
        {d.saving.every((v) => v === 0) ? (
          <ThemedText type="small" style={muted}>{t('fc.sav.none')}</ThemedText>
        ) : (
          <>
            <BarChart
              items={shownSaving.map((v, i) => {
                const key = d.past[d.past.length - shownSaving.length + i];
                return { key, label: monthLabel(key, 'short'), title: monthLabel(key, 'long'), value: v, color: v < 0 ? colors.negative : undefined };
              })}
              color={colors.accent}
              refLine={targetAmount > 0 ? { value: targetAmount, label: t('plan.deep.sav.target', { pct: savingsTarget, amount: money(targetAmount) }), color: colors.positive } : undefined}
              format={money}
            />
            {targetAmount > 0 ? (
              <ThemedText type="small" style={muted}>{t('plan.deep.sav.met', { n: metTarget, of: shownSaving.length })}</ThemedText>
            ) : null}
          </>
        )}
      </View>

      {section(t('fc.goalChart.title'))}
      <View style={card}>
        {!picked || !goalChart ? (
          <ThemedText type="small" style={muted}>{t('fc.goals.none')}</ThemedText>
        ) : (
          <>
            <View style={styles.chips}>
              {goalRows.map((r) => (
                <Chip key={r.g.id} label={r.g.name} active={r.g.id === picked.g.id} onPress={() => setPick(r.g.id)} />
              ))}
            </View>
            <LineChart
              labels={goalChart.labels}
              hide={hideAmounts}
              readout={(i) => {
                const rows: Readout['rows'] = [];
                const a = goalChart.actual[i];
                if (a !== null && a !== undefined) rows.push({ label: t('fc.goalChart.actual'), value: money(a), color: colors.accent });
                const pc = goalChart.pace?.[i];
                if (i >= HIST && pc !== null && pc !== undefined) rows.push({ label: t('fc.goalChart.pace'), value: money(pc), color: colors.positive });
                const sg = goalChart.suggest?.[i];
                if (i >= HIST && sg !== null && sg !== undefined) rows.push({ label: t('fc.goalChart.suggest'), value: money(sg), color: colors.negative });
                return { title: goalChart.labels[i], rows };
              }}
              splitAt={HIST}
              hline={{ value: goalChart.target, color: colors.warning }}
              series={[
                { values: goalChart.actual, color: colors.accent, dots: true },
                ...(goalChart.pace ? [{ values: goalChart.pace, color: colors.positive, dashed: true }] : []),
                ...(goalChart.suggest ? [{ values: goalChart.suggest, color: colors.negative, dashed: true }] : []),
              ]}
            />
            {legend([
              { c: colors.accent, k: t('fc.goalChart.actual') },
              ...(goalChart.pace ? [{ c: colors.positive, k: t('fc.goalChart.pace'), dashed: true }] : []),
              ...(goalChart.suggest ? [{ c: colors.negative, k: t('fc.goalChart.suggest'), dashed: true }] : []),
            ])}
            {goalChart.done ? (
              <ThemedText type="smallBold">{t('fc.goalChart.done')}</ThemedText>
            ) : (
              <>
                <ThemedText type="small">
                  {goalChart.rate > 0
                    ? t('fc.goalChart.paceText', { amount: money(goalChart.rate), n: goalChart.monthsPace })
                    : t('fc.goals.noPace')}
                </ThemedText>
                {goalChart.need !== null ? (
                  <ThemedText type="small">{t('fc.goalChart.needText', { amount: money(goalChart.need), left: money(goalChart.remaining) })}</ThemedText>
                ) : (
                  <ThemedText type="small" style={muted}>{t('fc.goalChart.noDeadline')}</ThemedText>
                )}
                {goalChart.need !== null && goalChart.rate > 0 ? (
                  <ThemedText type="small" style={muted}>
                    {goalChart.rate >= goalChart.need
                      ? t('fc.goalChart.ontrack')
                      : t('fc.goalChart.short', { amount: money(goalChart.need - goalChart.rate) })}
                  </ThemedText>
                ) : null}
              </>
            )}
          </>
        )}
      </View>
      </>
      ) : null}

      {part === 'forecast' ? (
      <>
      {section(t('fc.totalChart.title'))}
      <View style={card}>
        <LineChart
          labels={totalChart.labels}
          hide={hideAmounts}
          readout={bandReadout(totalChart, colors.positive)}
          splitAt={totalChart.split}
          series={[
            { values: totalChart.hi, color: colors.textSecondary, dashed: true, width: 1.5 },
            { values: totalChart.lo, color: colors.textSecondary, dashed: true, width: 1.5 },
            { values: totalChart.mid, color: colors.positive, dashed: true },
            { values: totalChart.hist, color: colors.accent, dots: true },
          ]}
        />
        {legend([
          { c: colors.accent, k: t('fc.goalChart.actual') },
          { c: colors.positive, k: t('fc.totalChart.forecast'), dashed: true },
          { c: colors.textSecondary, k: t('fc.totalChart.range'), dashed: true },
        ])}
        <ThemedText type="small" style={muted}>{t('fc.totalChart.note')}</ThemedText>
      </View>

      {section(t('fc.spendChart.title'))}
      <View style={card}>
        <LineChart
          labels={spendChart.labels}
          hide={hideAmounts}
          readout={bandReadout(spendChart, colors.negative)}
          splitAt={spendChart.split}
          series={[
            { values: spendChart.hi, color: colors.textSecondary, dashed: true, width: 1.5 },
            { values: spendChart.lo, color: colors.textSecondary, dashed: true, width: 1.5 },
            { values: spendChart.mid, color: colors.negative, dashed: true },
            { values: spendChart.hist, color: colors.accent, dots: true },
          ]}
        />
        {legend([
          { c: colors.accent, k: t('fc.goalChart.actual') },
          { c: colors.negative, k: t('fc.totalChart.forecast'), dashed: true },
          { c: colors.textSecondary, k: t('fc.totalChart.range'), dashed: true },
        ])}
      </View>
      </>
      ) : null}

      {part === 'savings' ? (
      <>
      {section(t('fc.goals.title'))}
      <View style={card}>
        {goalRows.length === 0 ? (
          <ThemedText type="small" style={muted}>{t('fc.goals.none')}</ThemedText>
        ) : (
          goalRows.map(({ g, p, need, saved }) => {
            const pct = g.target > 0 ? Math.min(100, (saved / g.target) * 100) : 0;
            return (
            <View key={g.id} style={styles.block}>
              <View style={styles.bandRow}>
                <Ionicons name="flag-outline" size={16} color={colors.accent} />
                <ThemedText type="smallBold" style={styles.flex}>{g.name}</ThemedText>
                <ThemedText type="smallBold" style={{ color: pct >= 100 ? colors.positive : colors.text }}>{p1(pct)}%</ThemedText>
              </View>
              <View
                style={[styles.progress, { backgroundColor: colors.backgroundSelected }]}
                accessible
                accessibilityRole="progressbar"
                accessibilityValue={{ min: 0, max: 100, now: Math.round(pct) }}
              >
                <View style={{ width: `${Math.max(pct > 0 ? 2 : 0, pct)}%`, height: 8, borderRadius: Radius.pill, backgroundColor: pct >= 100 ? colors.positive : colors.accent }} />
              </View>
              <ThemedText type="small" style={muted}>{t('plan.deep.sav.progress', { saved: money(saved), target: money(g.target) })}</ThemedText>
              <ThemedText type="small" style={muted}>
                {p.finishDate ? t('fc.goals.finish', { date: monthLabel(p.finishDate.slice(0, 7), 'short') + ' ' + p.finishDate.slice(0, 4) }) : t('fc.goals.noPace')}
                {p.daysVsDeadline !== null
                  ? ` · ${p.daysVsDeadline > 0 ? t('fc.goals.late', { n: p.daysVsDeadline }) : t('fc.goals.early', { n: -p.daysVsDeadline })}`
                  : ''}
              </ThemedText>
              {need !== null ? <ThemedText type="small" style={muted}>{t('fc.goals.need', { amount: money(need) })}</ThemedText> : null}
            </View>
            );
          })
        )}
      </View>
      </>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  card: { borderRadius: Radius.lg, padding: 20, marginBottom: Spacing.three, gap: 10 },
  sectionTitle: { fontSize: FontSize.body, marginBottom: Spacing.two, marginTop: Spacing.two },
  trio: { flexDirection: 'row', gap: 12 },
  block: { gap: 4, marginBottom: 6 },
  bandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  monthCol: { width: 44 },
  progress: { height: 8, borderRadius: Radius.pill, overflow: 'hidden', marginVertical: 2 },
  gap: { marginTop: 6 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  legend: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
});
